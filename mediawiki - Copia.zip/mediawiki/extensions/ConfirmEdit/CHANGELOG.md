ConfirmEdit Changelog
=========

### Changelog

#### Version 1.2

Fixes bug 46132 - ConfirmEdit fatal error when using MathCaptcha and current Math extension.
See <https://phabricator.wikimedia.org/T48132>.
